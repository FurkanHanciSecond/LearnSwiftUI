import SwiftUI

struct TopExplanationView: View {
    @State private var pulsate : Bool = false
    var body: some View {
        HStack{
            Image(uiImage: UIImage(named: "hello")!).resizable().frame(width: 250, height: 250).rotationEffect(.degrees(-10)).scaleEffect(self.pulsate ? 0.4 : 1)
                .animation(self.pulsate ? Animation.easeIn(duration: 1).repeatForever(autoreverses: true) : Animation.easeInOut)
                .onAppear {
                    DispatchQueue.main.async {
                        self.pulsate.toggle()
                        
                    }
                }
            Spacer()
            Image(uiImage: UIImage(named: "hammer")!).resizable().frame(width: 200, height: 200)
        }
    }
}

struct ElementsPage: View {
    @State private var showButton = false
    
    @State private var startToPlay = false
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.mint , .orange], startPoint: .topTrailing, endPoint: .bottomLeading)
                .ignoresSafeArea()
        VStack{
            HStack{
                Spacer().frame(width: 50)
                Image(uiImage: UIImage(named: "swiftui")!).resizable().frame(width: 70, height: 70).offset(y: -6)
                Text("Some Of Elements In SwiftUI").font(.system(size: 40)).fontWeight(.bold).foregroundColor(.black)
                Spacer()
            }
            Spacer().frame(height: UIScreen.main.bounds.size.height * 0.06)
            ChangingElement {
                withAnimation(Animation.easeIn) {
                    showButton = true
                }
            }
            Spacer().frame(height: UIScreen.main.bounds.size.height * 0.15)
            buttonPlay().opacity(showButton ? 1 : 0)
        }.scaleEffect(0.5).fullScreenCover(isPresented: $startToPlay, content: {
            CardGamePage()
        })
    }
        
    }
    
    
    @ViewBuilder func buttonPlay() -> some View{
        ZStack{
            Rectangle().foregroundColor(.black)
            Text("PLAY").foregroundColor(.white).font(.system(size: 32)).fontWeight(.semibold)
        }.frame(width: UIScreen.main.bounds.width * 0.93, height: UIScreen.main.bounds.width * 0.1, alignment: .center).cornerRadius(15)
            .padding()
            .onTapGesture {
                startToPlay = true
            }
    }
}




struct HeaderExplanation: View {
    
    var text:String
    var body: some View {
        HStack{
            RoundedRectangle(cornerRadius: 20).frame(width: 5)
            Text(text).fontWeight(.bold).font(.system(size: 27)).padding(.leading,4).foregroundColor(.black)
            Spacer()
        }.frame(height: 40)
            .padding()
    }
}




struct WhoAmiDetail: View {
    
    var onStart: () -> ()
    @State private var heartSize = 55.0
    @State private var animStart : Bool = false
    @State private var animEnd : Bool = false
    private let startAnimDuration = 11.0
    private let endAnimDuration = 5.0
    @State private var buttonHidden : Bool = false
    @State private var finish : Bool = false
    private let seconds : Double = 10
    var body: some View {
        ZStack {
            AnimatedBackground(start: .topLeading, end: .bottomTrailing)
                .ignoresSafeArea()
            VStack{
                Spacer().frame(height: 20)
                TopExplanationView()
                Spacer().frame(height: 5)
                ScrollView{
                    informationText()
                    Spacer()
                    HeaderExplanation(text: "WHAT IS INSIDE THIS PLAYGROUND?")
                    whythisappText()
                    HeaderExplanation(text: "SECRET THING UNDER THE IMAGE (SCRATCH IT)")
                    EntryScratch(onEnd: {

                    }, cursorSize: 50, onFinish: $finish) {
                        Image(uiImage: UIImage(named: "swiftui")!)
                            .resizable()
                            .aspectRatio( contentMode: .fit)
                            .frame(width: 190, height: 190)
                            .cornerRadius(10)
                    } overlayView: {
                        Image(uiImage: UIImage(named: "pc")!)
                            .resizable()
                            .aspectRatio( contentMode: .fit)
                            .frame(width: 160, height: 160)
                            .cornerRadius(20)
                     
                    }

                }
                buttonStart()
                    .opacity(buttonHidden ? 1 : 0)
                    .animation(.easeInOut)
            }.scaleEffect(0.83)
        }.onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                self.buttonHidden = true
            }
        }
        
        
    }
    
    @ViewBuilder func buttonStart() -> some View{
        ZStack{
            Color.black
            Text("START").foregroundColor(.white).font(.system(size: 32)).fontWeight(.semibold)
        }.frame(width: UIScreen.main.bounds.width * 0.90, height: UIScreen.main.bounds.width * 0.1, alignment: .center).cornerRadius(15)
            .padding()
            .onTapGesture {
                onStart()
            }
    }
    
    
    @ViewBuilder func informationText() -> some View{
        HStack{
            VStack(alignment: .leading,spacing: 20){
                Text("I'm Furkan! 16 years old from Turkey 🇹🇷").fontWeight(.bold).shadow(color: .blue, radius: 10, x: 10, y: 15).foregroundColor(.black)
                Text("I've been coding with Swift for 2 years 💻").fontWeight(.light).foregroundColor(.black)
                Text("I'm in love with Apple ❤️").fontWeight(.bold).foregroundColor(.black)
                Text("I hope you will like this little project 🚀").fontWeight(.light).foregroundColor(.black)
            }
            
            .font(.system(size: 30))
            Spacer()
        }.frame(height: 200)
            .padding(.horizontal)
            .padding(.leading)
    }
    
    @ViewBuilder func whythisappText() -> some View{
        VStack(alignment: .leading){
            Text("The team of Apple Developer ❤️ does amazing technologies like SwiftUI. In this playground I wanted to show you about the basics of SwiftUI with a little Game 🎮 I hope you will enjoy it and more develop your SwiftUI passion 🚀")
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .lineSpacing(10)
                .padding()
                .foregroundColor(.black)
                .rotation3DEffect(.degrees(animEnd ? 0 : 60), axis: (x: 0.2, y: 0, z: 0))
                .shadow(color: .gray, radius: 2, x: 0, y: 5)
                .frame(width: 600, height: animStart ? 350 : 0)
                .animation(Animation.linear(duration: animEnd ? endAnimDuration : startAnimDuration))
                .onAppear {
                    self.animStart.toggle()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + self.startAnimDuration) {
                        self.animEnd.toggle()
                    }
                }
            
        }.font(.system(size: 30))
            .padding(.horizontal)
    }
    
}

struct ContentView: View {
    
    @State var presentHeroes = false;
    var body: some View {
        WhoAmiDetail {
            presentHeroes = true
        }.fullScreenCover(isPresented: $presentHeroes, content: {
            ElementsPage()
        })
    }
}


struct ContentViewPreview : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
