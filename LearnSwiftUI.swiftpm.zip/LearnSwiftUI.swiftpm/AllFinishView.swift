//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI


struct FinalPage: View {
    let timer = Timer.publish(every: 0.2, on: .main, in: .common).autoconnect()
    
    @State private var offSetNumber = UIScreen.main.bounds.size.height * 0.45
    
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.blue)
                .frame(width: 10, height: 10)
                .modifier(ParticleModifier())
                .offset(x: -150, y: -50)
            
            Circle()
                .fill(Color.red)
                .frame(width: 15, height: 15)
                .modifier(ParticleModifier())
                .offset(x: 60, y: 80)
            
            
            Circle()
                .fill(Color.green)
                .frame(width: 15, height: 15)
                .modifier(ParticleModifier())
                .offset(x: 160, y: 90)
        VStack{
            Image(uiImage: UIImage(named: "apple")!).resizable().frame(width: UIScreen.main.bounds.size.width * 0.2, height: UIScreen.main.bounds.size.width * 0.2)
            Text("THE END").bold().font(.system(size: 40))
            Text("Thanks for using my app. Of course basic elements of the SwiftUI is not limited with 9 elements. There are too much but I couldn't mention all of them in this project. After that keep reserching and creating something new. See you in the Dub Dub 🤟").fontWeight(.light).font(.system(size: 35)).padding().fixedSize(horizontal: false, vertical: true)
                        
            Spacer().frame(height: 50)
            Spacer().frame(height: 50)
            ZStack{
                RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 4).foregroundColor(.brown)
                VStack{
                    Text("Think Different.").fontWeight(.bold).font(.system(size: 50))
                    Text("Thank you for reviewing my App!").fontWeight(.light).font(.system(size: 30))
                }
            }.frame(width: UIScreen.main.bounds.size.width * 0.9, height: UIScreen.main.bounds.size.width * 0.15, alignment: .center)
            
        }.scaleEffect(0.8)
            .offset(y: CGFloat(offSetNumber))
            .onReceive(timer) { input in
                withAnimation(Animation.linear, {
                    if (offSetNumber > 100){
                        offSetNumber -= 10
                    }else if (offSetNumber > -170){
                        offSetNumber -= 21
                    }
                })
            }
    }
        
    }
}
