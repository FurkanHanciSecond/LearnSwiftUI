//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct CardGamePage: View {
    @ObservedObject var deck = Deck()
    
    @State private var state = GameState.start
    @State private var firstIndex: Int?
    @State private var secondIndex: Int?
    @StateObject var presentClass = PresentModelClass()

    
    @State private var allFinished = false
    let rowCount = 3
    let columnCount = 6
    
    var body: some View {
        ZStack {
            LinearGradient(colors: [.mint , .orange], startPoint: .bottomLeading , endPoint: .topTrailing)
                .ignoresSafeArea()
        if (allFinished){
            CardFinishPage()
                .scaleEffect(0.4)
        }else{
            gamePage()
                .scaleEffect(0.5)
                .onAppear{
                    for i in 0...deck.cardParts.count - 1{
                        deck.set(i, to: .scratched)
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        for i in 0...self.deck.cardParts.count - 1{
                            withAnimation{
                                deck.set(i, to: .unscratched)
                            }
                        }
                    }
                }
        }
        }
    }
    
    @ViewBuilder func gamePage() -> some View{
        ZStack {
            VStack {
                Spacer()
                titleText()
                Spacer()
                GridStack(rows: rowCount, columns: columnCount, content: card)
                Spacer()
                Spacer()
            }
            .padding()
        }
        .fullScreenCover(isPresented: $presentClass.isPresented, onDismiss: {
            let x = deck.cardParts.filter { (model) -> Bool in
                model.state != .matched
            }
            if (x.isEmpty){
                withAnimation(Animation.easeIn) {
                    allFinished = true
                }
            }
            
        }, content: {
            DetailsPage(cardModel: presentClass.modelToPresent, isPresented: $presentClass.isPresented)
        })
        
    }
    
    @ViewBuilder func titleText() -> some View{
        HStack{
            Spacer().frame(width: 30)
            Text("Element Matching").font(.system(size: 60)).fontWeight(.bold).foregroundColor(.black)
            Spacer()
        }
    }
    
    @State private var finish : Bool = false
    
    func card(atRow row: Int, column: Int) -> some View {
        let index = (row * columnCount) + column
        let part = deck.cardParts[index]
        
        return ScratchCardView(onEnd: {
            self.flip(index)
        }, cursorSize: 50, onFinish: $finish) {
            CardFront(cardPart: part)
            
        } overlayView: {
            CardView(cardPart: part)
            
           
    }
        .opacity(part.state == .matched ? 0 : 1)
        .shadow(radius: 20)
    }
    
    func flip(_ index: Int) {
        guard deck.cardParts[index].state == .unscratched else { return }
        guard secondIndex == nil else { return }
        
        switch state {
        case .start:
            withAnimation {
                self.firstIndex = index
                self.deck.set(index, to: .scratched)
                self.state = .firstScratched
            }
        case .firstScratched:
            withAnimation {
                self.secondIndex = index
                self.deck.set(index, to: .scratched)
                self.checkMatches()
            }
        }
    }
    
    func match() {
        guard let first = firstIndex, let second = secondIndex else {
            fatalError("There must be two flipped cards before matching.")
        }
        
        withAnimation {
            deck.set(first, to: .matched)
            deck.set(second, to: .matched)
        }
        
        reset()
        presentClass.modelToPresent = deck.cardParts[first]
    }
    
    func noMatch() {
        guard let first = firstIndex, let second = secondIndex else {
            fatalError("There must be two flipped cards before matching.")
        }
        
        withAnimation {
            deck.set(first, to: .unscratched)
            deck.set(second, to: .unscratched)
        }
        
        reset()
    }
    
    func reset() {
        firstIndex = nil
        secondIndex = nil
        state = .start
    }
    
    func checkMatches() {
        guard let first = firstIndex, let second = secondIndex else {
            fatalError("There must be two flipped cards before matching")
        }
        
        if deck.cardParts[first].matchID == deck.cardParts[second].matchID {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: match)
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: noMatch)
        }
    }
}
