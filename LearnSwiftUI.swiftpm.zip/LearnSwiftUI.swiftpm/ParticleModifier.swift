//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct ParticleModifier : ViewModifier {
    @State private var time : Double = 0.0
    @State private var scale : Double = 0.1
    private let duration = 10.0
    
    func body(content: Content) -> some View {
        ZStack {
            ForEach(0..<250 , id: \.self) { index in
                
                content
                    .hueRotation(Angle(degrees: time * 90))
                    .scaleEffect(scale)
                    .modifier(ParticleEffect(time: time))
                    .opacity((duration - time) / duration)
            }
        }
        .onAppear {
            withAnimation (.easeInOut(duration: duration)) {
                self.time = duration
                self.scale = 2.0
            }
        }
    }
}
