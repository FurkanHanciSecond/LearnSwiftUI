//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI
struct DetailsPage: View {
    var cardModel:CardModel
    @Binding var isPresented:Bool
    
    var body: some View {
        ScrollView{
            Spacer().frame(height: 10)
            nameText()
            Spacer().frame(height: 10)
            modelImage().scaleEffect(0.9)
            Spacer().frame(height: 5)
            Text(cardModel.description).fontWeight(.light).lineSpacing(6).font(.system(size: 30)).padding().fixedSize(horizontal: false, vertical: true)
            buttonClose()
        }.scaleEffect(0.8)
    }
    @ViewBuilder func buttonCloseCircle() -> some View{
        Circle().frame(width: 60,height: 60).overlay(
            Text("X").font(.system(size: 26)).foregroundColor(.white).bold()
        ).offset(y: -10)
            .onTapGesture {
                isPresented = false
            }
    }
    
    @ViewBuilder func buttonClose() -> some View{
        ZStack{
            Rectangle()
            Text("CLOSE").foregroundColor(.white).font(.system(size: 32)).fontWeight(.semibold)
        }.frame(width: UIScreen.main.bounds.width * 0.93, height: UIScreen.main.bounds.width * 0.1, alignment: .center).cornerRadius(15)
            .padding()
            .onTapGesture {
                isPresented = false
            }
    }
    
    @ViewBuilder func nameText() -> some View{
        HStack{
            Spacer().frame(width: 25)
            Image(uiImage: UIImage(named: "swiftui")!).resizable().frame(width: 70, height: 70).offset(y: -6)
            Text(cardModel.name).font(.system(size: 35)).fontWeight(.bold).foregroundColor(.black)
            Spacer()
            buttonCloseCircle()
            Spacer().frame(width: 20)
        }
    }
    
    @ViewBuilder func modelImage() -> some View{
        HStack(spacing: 10) {
        ZStack {
            Image(cardModel.detailImage)
                .resizable()
                .scaledToFit()
                .frame(width: UIScreen.main.bounds.size.width * 0.6, height: UIScreen.main.bounds.size.width * 0.48)
        }
            Image(cardModel.image)
                .resizable()
                .scaledToFit()
                .frame(width: UIScreen.main.bounds.size.width * 0.5, height: UIScreen.main.bounds.size.width * 0.45)

    }
    }
}
