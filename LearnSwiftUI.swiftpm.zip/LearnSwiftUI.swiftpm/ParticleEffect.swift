//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//


import SwiftUI

struct ParticleEffect : GeometryEffect {
    var time : Double
    var speed = Double.random(in: 30 ... 300)
    var direction = Double.random(in: -Double.pi ... Double.pi)
    
    var animatableData: Double {
        get { time }
        set { time = newValue }
    }
    
    func effectValue(size: CGSize) -> ProjectionTransform {
        let xTrans = speed * cos(direction) * time
        let yTrans = speed * sin(direction) * time
        let affineTrans = CGAffineTransform(translationX: xTrans, y: yTrans)
        return ProjectionTransform(affineTrans)
    }
}
