//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI


struct CardModel:Identifiable{
    var matchID:UUID
    var cardID:Int
    var name : String
    var description : String
    var image : String
    var detailImage : String
    var id = UUID()
    var state = CardState.unscratched
}


enum CardState {
    case unscratched, scratched, matched
}


enum GameState {
    case start, firstScratched
}


var hstack = CardModel(matchID: UUID(),cardID: 0, name: "HStack", description: "A view that arranges its children in a horizontal line.", image: "hstack", detailImage: "hstackdtl")

var zstack = CardModel(matchID: UUID(),cardID: 1, name: "ZStack", description: "A view that overlays its children, aligning them in both axes." , image: "zstack", detailImage: "zstackdtl")

var vstack = CardModel(matchID: UUID(),cardID: 2, name: "VStack", description: "A view that arranges its children in a vertical line." , image: "vstack", detailImage: "vstackdtl")

var text =  CardModel(matchID: UUID(),cardID: 3, name: "Text", description: "A view that displays one or more lines of read-only text.", image: "text", detailImage: "textdtl")

var button = CardModel(matchID: UUID(),cardID: 4, name: "Button", description: "A Button is a type of control that performs an action when it is triggered. In SwiftUI, a Button typically requires a title text which is the text description of your button, and an action function that will handle an event action when triggered by the user.", image: "button", detailImage: "buttondtl")

var list = CardModel(matchID: UUID(),cardID: 5, name: "List", description: "A container that presents rows of data arranged in a single column, optionally providing the ability to select one or more members.", image: "list", detailImage: "listdtl")

var stepper = CardModel(matchID: UUID(),cardID: 6, name: "Stepper", description: "A control that performs increment and decrement actions.", image: "stepper", detailImage: "stepperdtl")

var textfield = CardModel(matchID: UUID(),cardID: 7, name: "TextField", description: "A TextField is a type of control that shows an editable text interface. In SwiftUI, a TextField typically requires a placeholder text which acts similar to a hint, and a State variable that will accept the input from the user (which is usually a Text value).", image: "textfield", detailImage: "textfieldtl")

var toggle = CardModel(matchID: UUID(),cardID: 8, name: "Toggle", description: "Toggle for SwiftUI allows developers to easily create a switch-like control for making on and off states.", image: "toggle", detailImage: "toggledtl")


var allElements = [hstack , zstack , vstack , text , button , list , stepper , textfield , toggle]
