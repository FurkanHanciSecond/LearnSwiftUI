//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct EntryScratch<Content: View, OverlayView: View>: View {
    var content : Content
    var overlayView: OverlayView
    var onEnd : () -> ()
    
    init(onEnd : @escaping () -> () , cursorSize: CGFloat, onFinish: Binding<Bool> , @ViewBuilder content: @escaping ()-> Content , @ViewBuilder overlayView: @escaping ()-> OverlayView) {
        self.content = content()
        self.overlayView = overlayView()
        self.cursorSize = cursorSize
        self._onFinish = onFinish
        self.onEnd = onEnd
    }
    
    @State private var startingPoint: CGPoint = .zero
    @State private var points: [CGPoint] = []
    @GestureState private var gestureLocation : CGPoint = .zero
    
    var cursorSize: CGFloat
    @Binding var onFinish: Bool
    
    var body: some View {
        ZStack {
            
            overlayView
                .opacity(onFinish ? 0 : 1)
            
            content
                .mask(
                    ZStack {
                        if !onFinish {
                            ScratchMask(points: points, startingPoint: startingPoint)
                                .stroke(style: StrokeStyle(lineWidth: cursorSize, lineCap: .round, lineJoin: .round))
                        } else {
                            Rectangle()
                        }
                    }
                )
                .animation(.easeInOut)
                .gesture(
                    DragGesture().updating($gestureLocation, body: { value, out, _ in
                        out = value.location
                        DispatchQueue.main.async {
                            if startingPoint == .zero {
                                startingPoint = value.location
                            }
                            points.append(value.location)
                        }
                    })
                    
                        .onEnded({ value in
                            withAnimation {
                                onFinish = true
                                onEnd()
                                print("end")
                            }
                        })
                )
                        
        }
        .frame(width: UIScreen.main.bounds.size.width / 4.75 , height: UIScreen.main.bounds.size.height / 6)
        .cornerRadius(20)
        // .padding(.bottom , 10)
        .onChange(of: onFinish) { value in
            if !onFinish && !points.isEmpty {
                withAnimation(.easeInOut) {
                    resetView()
                }
            }
        }
    }
    
    func resetView() {
        points.removeAll()
        startingPoint = .zero
    }
    
}


struct EntryScratchMask: Shape {
    var points : [CGPoint]
    var startingPoint : CGPoint
    
    func path(in rect: CGRect) -> Path {
        
        return Path { path in
            path.move(to: startingPoint)
            path.addLines(points)
        }
    }
}
