//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct ChangingElement: View {
    
    var completed: () -> ()
    
    @State private var currentText = "HStack"
    
    @State private var timeRemaining = -1
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 20).stroke(lineWidth: 8).foregroundColor(.white)
                .frame(width: UIScreen.main.bounds.size.width , height: UIScreen.main.bounds.size.height * 0.5)
                Text(currentText)
                    .font(.system(size: 70))
                    .animation(.easeInOut)
                    .foregroundColor(.black)

            .onReceive(timer) { time in
                if self.timeRemaining < 8 {
                    self.timeRemaining += 1
                    currentText = allElements[timeRemaining].name
                }else{
                    completed()
                }
            }
        }
    }
}
