//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

class Deck: ObservableObject {
    var allCards = allElements
    var cardParts = [CardModel]()
    
    init() {
        let selectedCards = allCards.shuffled()
        for card in selectedCards {
            var id = UUID()
            var card1 = CardModel(matchID: id,cardID: card.cardID, name: card.name, description: card.description, image: card.image, detailImage: card.detailImage)
            var card2 = CardModel(matchID: id,cardID: card.cardID, name: card.name, description: card.description, image: card.image, detailImage: card.detailImage)
            cardParts.append(card1)
            cardParts.append(card2)
        }
        
        cardParts.shuffle()
    }
    
    func set(_ index: Int, to state: CardState) {
        cardParts[index].state = state
        objectWillChange.send()
    }
}
