//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct ScratchCardView<Content: View, OverlayView: View>: View {
    var content : Content
    var overlayView: OverlayView
    var onEnd : () -> ()
    
    init(onEnd : @escaping () -> () , cursorSize: CGFloat, onFinish: Binding<Bool> , @ViewBuilder content: @escaping ()-> Content , @ViewBuilder overlayView: @escaping ()-> OverlayView) {
        self.content = content()
        self.overlayView = overlayView()
        self.cursorSize = cursorSize
        self._onFinish = onFinish
        self.onEnd = onEnd
    }
    
    @State private var startingPoint: CGPoint = .zero
    @State private var points: [CGPoint] = []
    @GestureState private var gestureLocation : CGPoint = .zero
    
    var cursorSize: CGFloat
    @Binding var onFinish: Bool
    
    var body: some View {
        ZStack {
            
            overlayView
            
            content
                .mask(
                    ZStack {
                        if !onFinish {
                            ScratchMask(points: points, startingPoint: startingPoint)
                                .stroke(style: StrokeStyle(lineWidth: cursorSize, lineCap: .round, lineJoin: .round))
                        } else {
                            Rectangle()
                        }
                    }
                )
                .animation(.easeInOut)
                .gesture(
                    DragGesture().updating($gestureLocation, body: { value, out, _ in
                        out = value.location
                        DispatchQueue.main.async {
                            if startingPoint == .zero {
                                startingPoint = value.location
                            }
                            points.append(value.location)
                        }
                    })
                    
                        .onEnded({ value in
                            withAnimation {
                                onFinish = false
                                onEnd()
                                print("end")
                                self.resetView()
                            }
                        })
                )
                        
        }
        .cornerRadius(20)
        .onChange(of: onFinish) { value in
            if !onFinish && !points.isEmpty {
                withAnimation(.easeInOut) {
                    resetView()
                }
            }
        }
    }
    
    func resetView() {
        points.removeAll()
        startingPoint = .zero
    }
    
}


struct ScratchMask: Shape {
    var points : [CGPoint]
    var startingPoint : CGPoint
    
    func path(in rect: CGRect) -> Path {
        
        return Path { path in
            path.move(to: startingPoint)
            path.addLines(points)
        }
    }
}


