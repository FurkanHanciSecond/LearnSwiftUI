//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

class PresentModelClass:ObservableObject{
    @Published var modelToPresent = hstack{
        didSet{
            isPresented = true
            presentChoose = PresentChoose.detail
        }
    }
    @Published var isPresented = false
    
    @Published var presentChoose = PresentChoose.detail
}

enum PresentChoose{
    case detail
    case finish
}
