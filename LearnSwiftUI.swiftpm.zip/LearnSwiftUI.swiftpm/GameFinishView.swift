//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct CardFinishPage: View {
    
    @StateObject var presentClass = PresentModelClass()
    
    var body: some View {
        VStack{
            Spacer()
            titleText().padding(.vertical)
            Spacer()
            allUI()
            Spacer()
            buttonFinish()
        }.fullScreenCover(isPresented: $presentClass.isPresented, content: {
            if (presentClass.presentChoose == PresentChoose.detail){
                DetailsPage(cardModel: presentClass.modelToPresent, isPresented: $presentClass.isPresented)
            }else{
                FinalPage()
            }
        })
    }
    
    @ViewBuilder func buttonFinish() -> some View{
        ZStack{
            Rectangle()
            Text("DONE!").foregroundColor(.white).font(.system(size: 32)).fontWeight(.semibold)
        }.frame(width: UIScreen.main.bounds.width * 0.95, height: UIScreen.main.bounds.width * 0.2, alignment: .center).cornerRadius(15)
            .padding()
            .onTapGesture {
                presentClass.presentChoose = PresentChoose.finish
                presentClass.isPresented = true
            }
        
    }
    
    @ViewBuilder func titleText() -> some View{
        HStack{
            Spacer().frame(width: 30)
            Image(uiImage: UIImage(named: "swiftui")!).resizable().frame(width: 70, height: 70).offset(y: -6)
            VStack(alignment: .leading){
                Text("Power of SwiftUI 🚀").font(.system(size: 35)).fontWeight(.bold)
                Text("Click on the cards for more information").font(.system(size: 25)).fontWeight(.thin)
                
            }
            Spacer()
        }
    }
    
    @ViewBuilder func allUI() -> some View{
        VStack{
            
            HStack{
                CardFront(cardPart: allElements[0])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[0]
                    }
                CardFront(cardPart: allElements[1])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[1]
                    }
                CardFront(cardPart: allElements[2])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[2]
                    }
            }
            HStack{
                CardFront(cardPart: allElements[3])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[3]
                    }
                CardFront(cardPart: allElements[4])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[4]
                    }
                CardFront(cardPart: allElements[5])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[5]
                    }
            }
            HStack{
                CardFront(cardPart: allElements[6])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[6]
                    }
                CardFront(cardPart: allElements[7])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[7]
                    }
                CardFront(cardPart: allElements[8])
                    .frame(width: UIScreen.main.bounds.width * 0.4, height: UIScreen.main.bounds.width * 0.5).cornerRadius(12).padding(8).onTapGesture {
                        presentClass.modelToPresent = allElements[8]
                    }
            }
        }
    }
}
