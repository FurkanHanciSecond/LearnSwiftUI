//
//  File.swift
//  LearnSwiftUI
//
//  Created by Furkan Hanci on 4/22/22.
//

import SwiftUI

struct CardView: View {
    var cardPart: CardModel
    
    var body: some View {
        ZStack {
            CardBack()
                .opacity(cardPart.state == .unscratched ?  1 : 0)
            
            CardFront(cardPart: cardPart)
                .opacity(cardPart.state != .unscratched ? 1 : -1)
        }
        .frame(width: UIScreen.main.bounds.size.width / 4, height: UIScreen.main.bounds.width * 0.25).cornerRadius(12)
    }
}

struct CardBack: View {
    var body: some View {
            Image(uiImage: UIImage(named: "swiftui")!)
                .resizable()
    }
}

struct CardFront: View {
    var cardPart: CardModel
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20).frame(width: 200, height: 200).foregroundColor(.black)
            Text(cardPart.name)
                .foregroundColor(.white)
                .font(.system(size: 50))
                
        }
        
        
    }
    
}
